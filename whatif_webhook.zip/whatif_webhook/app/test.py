import sqlite3
import datetime

request_json = {
    "id": "8946be9a-70ae-4d98-a993-9bcbe59c2a6a",
    "channel": "LIVE_CHAT",
    "from": "6c59240f-c4f9-47c1-8d2c-cddbbdfd770b",
    "to": "a4d2b56e-3758-413f-8dff-e62933260f71",
    "direction": "INBOUND",
    "conversationId": "051a5884-8cf9-42da-8c3c-5c0580f07426",
    "createdAt": "2024-01-28T14:47:19.139+00:00",
    "updatedAt": "2024-01-28T14:47:19.153+00:00",
    "content": {
        "text": "Start the chat",
        "showUrlPreview": "null"
    },
    "singleSendMessage": {
        "from": {
            "id": "6c59240f-c4f9-47c1-8d2c-cddbbdfd770b",
            "type": "LIVE_CHAT_REGISTRATION"
        },
        "to": {
            "id": "a4d2b56e-3758-413f-8dff-e62933260f71",
            "type": "LIVE_CHAT_APPLICATION"
        },
        "content": {
            "text": "Start the chat",
            "type": "TEXT"
        },
        "channel": "LIVE_CHAT",
        "direction": "INBOUND"
    },
    "contentType": "TEXT"
}

response = {"id":"842b77e1-1b6d-4aa6-a3bd-41a7c182ff90",
 "channel":"LIVE_CHAT",
 "from":"a4d2b56e-3758-413f-8dff-e62933260f71",
 "to":"7fbb68f3-2072-48c2-8e4a-f96031c30350",
 "direction":"OUTBOUND",
 "conversationId":"8f7be138-3418-461f-aa27-814d92558d6c",
 "createdAt":"2024-01-30T14:08:11.959+00:00",
 "updatedAt":"2024-01-30T14:08:11.959+00:00",
 "content":{"text":"Transferring to an agent","showUrlPreview":"null"},
 "singleSendMessage":{"from":{"id":"a4d2b56e-3758-413f-8dff-e62933260f71","type":"LIVE_CHAT_APPLICATION"},
                      "to":{"id":"7fbb68f3-2072-48c2-8e4a-f96031c30350","type":"LIVE_CHAT_REGISTRATION"},
                      "content":{"text":"Transferring to an agent","type":"TEXT"},
                      "channel":"LIVE_CHAT","direction":"OUTBOUND"},
                      "contentType":"TEXT"}






connection = sqlite3.connect('database.db')

def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn


#with open('schema.sql') as f:
    #connection.executescript(f.read())

def insert_event(request_json, text):
    conversation_id = request_json["conversationId"]
    incoming_event = text
    incoming_date = datetime.datetime.now()
    outgoing_answer = "Let's stat"
    outgoing_date = datetime.datetime.now()
    message_id = "1"
    cur = connection.cursor()

    cur.execute("INSERT INTO events (conversation_id, incoming_event, incoming_date, outgoing_answer, outgoing_date, message_id) VALUES (?, ?, ?, ?, ?, ?)",
                (conversation_id, incoming_event, incoming_date, outgoing_answer, outgoing_date, message_id)
                )
    connection.commit()
    connection.close()



def read_latest(conversation_id):
    conn = get_db_connection()
    posts = conn.execute("SELECT * FROM events where conversation_id = ? ORDER BY incoming_date DESC LIMIT 1", [conversation_id]).fetchall()
    conn.close()
    return (posts[0][2])

#insert_event(request_json, "text10")
posts = read_latest("051a5884-8cf9-42da-8c3c-5c0580f07426")
print(posts)

