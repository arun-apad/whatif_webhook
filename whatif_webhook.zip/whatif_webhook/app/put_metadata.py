import http.client
import json

conn = http.client.HTTPSConnection("qgjr3q.api.infobip.com")
payload = json.dumps({
    "key1": "value1",
    "key2": "value2"
})
headers = {
    'Authorization': 'App b7bf742704592bdd3ea396da9fd2dfbb-f8a731d3-78ee-40d0-8e51-9589cda6b5ef',
    'Content-Type': 'application/json',
    'Accept': 'application/json'
}
print("Call to update")
conn.request("PUT", "/ccaas/1/conversations/fb4166e3-b2c8-4774-8497-954f9b44f704/metadata", payload, headers)
res = conn.getresponse()
data = res.read()
print(data.decode("utf-8"))
print("Updated")