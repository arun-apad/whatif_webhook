#WEBHOOK_URL = 'https://127.0.0.1/webhook'  # test with Flask receiver 
WEBHOOK_USERNAME = 'testagent'
WEBHOOK_PASSWORD = 'testagent'
WIFTESTBOT = {
    'Authorization': 'App b7bf742704592bdd3ea396da9fd2dfbb-f8a731d3-78ee-40d0-8e51-9589cda6b5ef',
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'x-agent-id': '6141d3ef-213b-47f0-98e0-e57bb496e0a2'
    }