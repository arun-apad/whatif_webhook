
import requests
import json
import urllib3



from requests.auth import HTTPBasicAuth  # for Basic Auth

from urllib3.exceptions import InsecureRequestWarning  # for insecure https warnings

urllib3.disable_warnings(InsecureRequestWarning)  # disable insecure https warnings

from config import WEBHOOK_USERNAME, WEBHOOK_PASSWORD


# set the payload for a Infobip sample notification event notification

payload = {
    "id": "8946be9a-70ae-4d98-a993-9bcbe59c2a6a",
    "channel": "LIVE_CHAT",
    "from": "6c59240f-c4f9-47c1-8d2c-cddbbdfd770b",
    "to": "a4d2b56e-3758-413f-8dff-e62933260f71",
    "direction": "INBOUND",
    "conversationId": "051a5884-8cf9-42da-8c3c-5c0580f07426",
    "createdAt": "2024-01-28T14:47:19.139+00:00",
    "updatedAt": "2024-01-28T14:47:19.153+00:00",
    "content": {
        "text": "Start the chat",
        "showUrlPreview": "null"
    },
    "singleSendMessage": {
        "from": {
            "id": "6c59240f-c4f9-47c1-8d2c-cddbbdfd770b",
            "type": "LIVE_CHAT_REGISTRATION"
        },
        "to": {
            "id": "a4d2b56e-3758-413f-8dff-e62933260f71",
            "type": "LIVE_CHAT_APPLICATION"
        },
        "content": {
            "text": "Start the chat",
            "type": "TEXT"
        },
        "channel": "LIVE_CHAT",
        "direction": "INBOUND"
    },
    "contentType": "TEXT"

}






# test the Webhook with a Infobip sample notification

basic_auth = HTTPBasicAuth(WEBHOOK_USERNAME, WEBHOOK_PASSWORD)


#url = "https://127.0.0.1:5000/webhook"
url = "http://localhost:55045/webhook"
#url = "https://middleware-travel-whatif-chatbot-preprod-axa-assist.axa-assist-preprod-hpl-ext.merlot.eu-central-1.aws.openpaas.axa-cloud.com/webhook"
#url = "https://middleware-travel-whatif-chatbot-preprod-axa-assist.axa-assist-preprod-hpl-ext.merlot.eu-central-1.aws.openpaas.axa-cloud.com/webhook"
#url = "https://arunpadmanabhan.eu.pythonanywhere.com/webhook"


header = {'content-type': 'application/json'}
response = requests.post(url, auth=basic_auth, data=json.dumps(payload), headers=header, verify=False)
print('\nWebhook notification status code: ', response.status_code)
print('\nWebhook notification response: ', response.text) 




#/*{"id":"0f1531f8-a891-4263-ba5b-f783feb42f95","channel":"LIVE_CHAT","from":"f6f4b9b5-26b6-451c-8b89-d0bae9cb9483","to":"a4d2b56e-3758-413f-8dff-e62933260f71","direction":"INBOUND","conversationId":"94b53c27-7bd2-47df-a290-22f19eb75e8c","createdAt":"2024-01-16T14:39:56.046+00:00","updatedAt":"2024-01-16T14:39:56.361+00:00","content":{"text":"Hello, need, lost, passport, help.","showUrlPreview":null},"singleSendMessage":{"from":{"id":"f6f4b9b5-26b6-451c-8b89-d0bae9cb9483","type":"LIVE_CHAT_REGISTRATION"},"to":{"id":"a4d2b56e-3758-413f-8dff-e62933260f71","type":"LIVE_CHAT_APPLICATION"},"content":{"text":"Hello, need, lost, passport, help.","type":"TEXT"},"channel":"LIVE_CHAT","direction":"INBOUND"},"contentType":"TEXT"}*/

