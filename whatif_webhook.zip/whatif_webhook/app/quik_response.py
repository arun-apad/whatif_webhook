import http.client
import json

conn = http.client.HTTPSConnection("qgjr3q.api.infobip.com")
payload = json.dumps({
   "from": "a4d2b56e-3758-413f-8dff-e62933260f71",
    "to": "a5afdbfe-2e60-4281-be86-299d8f8bef60",
    "channel": "LIVE_CHAT",
    "contentType": "LC_QUICK_REPLY",
    "content": {
        "suggestedReplies": [
            "Yes",
            "No"
        ],
        "sourceType": "TEXT",
        "source": {
            "text": "Ready to ask?"
        }
    }
})
headers = {
    'Authorization': 'App b7bf742704592bdd3ea396da9fd2dfbb-f8a731d3-78ee-40d0-8e51-9589cda6b5ef',
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'x-agent-id': '6141d3ef-213b-47f0-98e0-e57bb496e0a2'
}
conn.request("POST", "/ccaas/1/conversations/b817da2c-506f-4824-9ce0-ce8ded9a60de/messages", payload, headers)
res = conn.getresponse()
data = res.read()
print(data.decode("utf-8"))


