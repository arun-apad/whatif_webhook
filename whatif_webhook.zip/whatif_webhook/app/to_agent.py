import http.client
import json

conn = http.client.HTTPSConnection("qgjr3q.api.infobip.com")
payload = json.dumps({
    "agentId": ""
})
headers = {
    'Authorization': 'App b7bf742704592bdd3ea396da9fd2dfbb-f8a731d3-78ee-40d0-8e51-9589cda6b5ef',
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'x-agent-id': '6141d3ef-213b-47f0-98e0-e57bb496e0a2'
}
conn.request("DELETE", "/ccaas/1/conversations/4cacb59f-5103-426c-a64b-199ae9c9036c/assignee", payload, headers)
res = conn.getresponse()
data = res.read()
print(data.decode("utf-8"))