import http.client
import json

conn = http.client.HTTPSConnection("qgjr3q.api.infobip.com")
payload = json.dumps({
     "from": "a4d2b56e-3758-413f-8dff-e62933260f71",
    "to": "6d038923-2d29-4081-8d9b-9a442d578efa",
    "channel": "LIVE_CHAT",
    "contentType": "BUTTON",
    "content": {
        "buttonType": "LIVECHAT",
        "button": {
            "text": "Try options below:",
            "buttonPayloads": [
                {
                    "title": "Yes test1",
                    "type": "POSTBACK",
                    "payload": "Yes"
                },
                {
                    "title": "No test1",
                    "type": "POSTBACK",
                    "payload": "No"
                },
                {
                    "title": "Google test1",
                    "type": "URL",
                    "payload": "https://google.com"
                }
            ]
        }
    }
})
headers = {
    'Authorization': 'App b7bf742704592bdd3ea396da9fd2dfbb-f8a731d3-78ee-40d0-8e51-9589cda6b5ef',
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'x-agent-id': '6141d3ef-213b-47f0-98e0-e57bb496e0a2'
}
conn.request("POST", "/ccaas/1/conversations/3ae133fd-b3ac-4b23-8ae9-75bd8d95ca18/messages", payload, headers)
res = conn.getresponse()
data = res.read()
print(data.decode("utf-8"))


